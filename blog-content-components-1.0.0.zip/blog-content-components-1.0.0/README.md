# Blog content components 1.0.0

Edge Delivery Services (Universal Editor / xwalk) components for the blog inner page:
editorial content, media player and sidebar cards, plus the Manrope site font.

Source branches: `blog-content-component` (components) and `manrope-site-font` (font)
in `aloksing-h/alok-aemcoder-agent`.

## Contents

| Path | What it is |
|---|---|
| `blocks/table-of-contents` | Table of contents: page navigation, highlights the section being read, collapsible on mobile |
| `blocks/table` | Comparison table (two columns by default) |
| `blocks/accordion` | FAQ accordion |
| `blocks/author-card` | "Written by" / "Reviewed by" card with photo, profile link and expandable bio |
| `blocks/prev-next` | Previous / next article links |
| `blocks/blog-media` | Primary media card: thumbnail first, player loads on click. AEM Assets video (with WebVTT captions), AEM Assets audio (waveform player), YouTube, Vimeo, or image only |
| `blocks/lead-form` | Lead form card with authorable fields, posts JSON to a configurable endpoint |
| `blocks/category-links` | "Explore other categories" link card |
| `icons/` | SVG icons used by the blocks |
| `styles/blog-content-section.css` | The `blog-content` section style: design tokens, two-column layout, editorial typography |
| `styles/manrope-font.css` | Manrope `@font-face` rules, the fallback face and the site font variables |
| `fonts/` | Manrope variable font, latin and latin-ext subsets (SIL Open Font License 1.1) |
| `models/section-additions.json` | What to add to `models/_section.json` |

## Install in an EDS xwalk project

1. Copy `blocks/`, `icons/` and `fonts/` into the project root.
2. Append `styles/blog-content-section.css` to the end of `styles/styles.css`.
3. Fonts:
   - append the two `@font-face { font-family: manrope; ... }` rules to `styles/fonts.css`;
   - add the `manrope-fallback` face to `styles/styles.css` next to the other fallback fonts;
   - set `--body-font-family` and `--heading-font-family` in `:root` as shown.
4. In `models/_section.json` add the "Blog content" style option and the 8 block ids to the
   `section` filter (see `models/section-additions.json`).
5. Run `npm run build:json`, then `npm run lint`.

## Authoring

- Give the section the style **Blog content**.
- Put the sidebar blocks (Table Of Contents, Lead Form, Category Links) first in the section,
  then the article content. Desktop shows them in a right column; mobile shows
  lead form, table of contents, content, then categories.
- Blog Media: choose the media type, then add a thumbnail (with alt text), the media source
  (AEM asset, YouTube or Vimeo URL), a media title (accessible name of the player) and,
  for AEM video, an optional WebVTT captions file.
- Table Of Contents: leave "Entries" empty to list every heading 2 of the section, or add a
  list of links to headings (e.g. `#a-simple-analogy`).
- Lead Form: set the submit endpoint URL; without it the form shows the authored error message.

## Notes

- Audio waveform: computed in the browser from audio files up to 10 minutes / 15 MB; longer
  files get a plain progress bar. The audio file must allow cross-origin requests.
  For long podcasts, pre-computed waveform data is recommended.
- DAM video and audio must be reachable from the live site (AEM publish or Dynamic Media).
- The active Table of contents number (white on #2E90FA) is below WCAG AA contrast for
  small text, as specified in the design.
